package com.dam.inventory;


import com.dam.inventory.model.Instrument;
import com.dam.inventory.repository.InstrumentRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class MusicInventoryApplication {

    public static void main(String[] args) {
        SpringApplication.run(MusicInventoryApplication.class, args);
    }

    @Bean
    CommandLineRunner initDatabase(InstrumentRepository repository) {
        return args -> {
            if (repository.count() == 0) {
                repository.save(new Instrument("Stratocaster", "Fender"));
                repository.save(new Instrument("Les Paul", "Gibson"));
                repository.save(new Instrument("Telecaster", "Fender"));
                System.out.println("--- Datos de prueba cargados ---");
            }
        };
    }
}
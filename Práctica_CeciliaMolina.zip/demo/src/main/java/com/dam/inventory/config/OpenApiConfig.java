package com.dam.inventory.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.Contact;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Music Inventory API - V3")
                        .version("1.0")
                        .description("Sistema de gestión de clientes e instrumentos con monitorización y validación avanzada.")
                        .contact(new Contact().name("Tu Nombre").email("tu@email.com")));
    }
}
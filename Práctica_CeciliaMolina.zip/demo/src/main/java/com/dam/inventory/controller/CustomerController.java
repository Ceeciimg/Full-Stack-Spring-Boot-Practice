package com.dam.inventory.controller;

import com.dam.inventory.dto.CustomerRequestDTO;
import com.dam.inventory.dto.CustomerResponseDTO;
import com.dam.inventory.dto.TaskResponseDTO;
import com.dam.inventory.service.CustomerService;
import com.dam.inventory.service.TaskService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @Autowired
    private TaskService taskService;

    @GetMapping
    public List<CustomerResponseDTO> getAll() {
        return customerService.findAll();
    }

    @GetMapping("/{id}")
    public CustomerResponseDTO getById(@PathVariable Long id) {
        return customerService.findById(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CustomerResponseDTO create(@Valid @RequestBody CustomerRequestDTO dto) {
        return customerService.create(dto);
    }

    @PutMapping("/{id}")
    public CustomerResponseDTO update(@PathVariable Long id, @Valid @RequestBody CustomerRequestDTO dto) {
        return customerService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        customerService.delete(id);
    }


    @GetMapping("/{id}/tasks")
    public List<TaskResponseDTO> getTasks(@PathVariable Long id) {
        return taskService.findByCustomer(id);
    }
}
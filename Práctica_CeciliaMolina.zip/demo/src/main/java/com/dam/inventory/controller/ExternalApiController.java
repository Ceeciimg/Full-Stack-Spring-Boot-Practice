package com.dam.inventory.controller;

import com.dam.inventory.dto.ExternalTrackDTO;
import com.dam.inventory.service.ExternalApiService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/external")
public class ExternalApiController {

    private final ExternalApiService externalApiService;

    public ExternalApiController(ExternalApiService externalApiService) {
        this.externalApiService = externalApiService;
    }

    @GetMapping("/search")
    public List<ExternalTrackDTO> search(@RequestParam String artist) {
        return externalApiService.searchMusic(artist);
    }
}
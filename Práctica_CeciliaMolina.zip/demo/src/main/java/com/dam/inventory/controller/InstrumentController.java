package com.dam.inventory.controller;

import com.dam.inventory.dto.InstrumentCreateDTO;

import com.dam.inventory.service.InstrumentService;
import com.dam.inventory.model.Instrument;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/instruments")
public class InstrumentController {

    @Autowired
    private InstrumentService service;

    @GetMapping
    public List<Instrument> getAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Instrument> getById(@PathVariable Long id) {
        return service.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/search")
    public List<Instrument> searchByBrand(@RequestParam String brand) {
        return service.findByBrand(brand);
    }

    @PostMapping
    public ResponseEntity<Instrument> create(@Valid @RequestBody InstrumentCreateDTO dto) {
        Instrument created = service.create(dto);


        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(created.getId())
                .toUri();

        return ResponseEntity.created(location).body(created);
    }
}
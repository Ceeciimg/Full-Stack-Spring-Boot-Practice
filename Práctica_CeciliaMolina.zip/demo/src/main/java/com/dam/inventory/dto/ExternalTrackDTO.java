package com.dam.inventory.dto;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExternalTrackDTO {
    private String artistName;
    private String trackName;
    private String previewUrl;
    private Double price;
    private String currency;
}
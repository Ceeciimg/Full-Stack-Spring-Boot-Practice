package com.dam.inventory.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class TaskRequestDTO {
    @NotBlank(message = "El título de la tarea es obligatorio")
    private String title;
}
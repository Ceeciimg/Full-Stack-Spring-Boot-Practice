package com.dam.inventory.exception;

import com.dam.inventory.dto.ErrorResponseDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {


    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<Map<String, String>> handleNotFound(RuntimeException ex) {
        Map<String, String> response = new HashMap<>();
        response.put("error", ex.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
    }


    @ExceptionHandler(IllegalStateException.class)
    public ResponseEntity<Map<String, String>> handleConflict(IllegalStateException ex) {
        Map<String, String> response = new HashMap<>();
        response.put("error", ex.getMessage());
        return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponseDTO> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(error ->
                errors.put(error.getField(), error.getDefaultMessage())
        );

        ErrorResponseDTO errorRes = new ErrorResponseDTO(
                LocalDateTime.now(),
                HttpStatus.BAD_REQUEST.value(),
                "Error de Validación",
                "Los datos enviados no son correctos",
                errors
        );

        return new ResponseEntity<>(errorRes, HttpStatus.BAD_REQUEST);
    }

    // Importa estas clases de org.springframework.web.client
    @ExceptionHandler(org.springframework.web.client.RestClientResponseException.class)
    public ResponseEntity<ErrorResponseDTO> handleExternalApiError(org.springframework.web.client.RestClientResponseException ex) {

        HttpStatus status = HttpStatus.BAD_GATEWAY; // Por defecto 502
        String message = "El servicio externo de música no responde correctamente";

        if (ex.getStatusCode().is4xxClientError()) {
            message = "La petición al servicio externo es incorrecta";
        }

        ErrorResponseDTO errorRes = new ErrorResponseDTO(
                java.time.LocalDateTime.now(),
                status.value(),
                "Error en Integración Externa",
                message,
                null
        );

        return new ResponseEntity<>(errorRes, status);
    }

    @ExceptionHandler(java.net.SocketTimeoutException.class)
    public ResponseEntity<ErrorResponseDTO> handleTimeout() {
        ErrorResponseDTO errorRes = new ErrorResponseDTO(
                java.time.LocalDateTime.now(),
                HttpStatus.GATEWAY_TIMEOUT.value(),
                "Timeout",
                "El servicio externo tardó demasiado en responder",
                null
        );
        return new ResponseEntity<>(errorRes, HttpStatus.GATEWAY_TIMEOUT);
    }
}
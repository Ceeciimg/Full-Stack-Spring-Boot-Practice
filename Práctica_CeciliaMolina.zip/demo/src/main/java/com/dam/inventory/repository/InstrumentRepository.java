package com.dam.inventory.repository;

import com.dam.inventory.model.Instrument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface InstrumentRepository extends JpaRepository<Instrument, Long> {


    List<Instrument> findByBrand(String brand);
    boolean existsByNameAndBrand(String name, String brand);
}
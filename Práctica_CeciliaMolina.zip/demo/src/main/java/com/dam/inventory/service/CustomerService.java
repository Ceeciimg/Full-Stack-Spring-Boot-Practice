package com.dam.inventory.service;

import com.dam.inventory.dto.CustomerRequestDTO;
import com.dam.inventory.dto.CustomerResponseDTO;
import com.dam.inventory.model.Customer;
import com.dam.inventory.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository repository;



    public List<CustomerResponseDTO> findAll() {
        return repository.findAll().stream()
                .map(this::convertToResponseDTO)
                .collect(Collectors.toList());
    }

    public CustomerResponseDTO findById(Long id) {
        Customer customer = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));
        return convertToResponseDTO(customer);
    }



    public CustomerResponseDTO create(CustomerRequestDTO dto) {

        String cleanEmail = dto.getEmail().trim();


        if (repository.findByEmail(cleanEmail).isPresent()) {
            throw new IllegalStateException("El email ya está registrado");
        }

        Customer customer = new Customer(dto.getName().trim(), cleanEmail);
        return convertToResponseDTO(repository.save(customer));
    }

    public CustomerResponseDTO update(Long id, CustomerRequestDTO dto) {
        Customer existing = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));

        existing.setName(dto.getName().trim());
        existing.setEmail(dto.getEmail().trim());

        return convertToResponseDTO(repository.save(existing));
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new RuntimeException("No se puede borrar: Cliente no encontrado");
        }
        repository.deleteById(id);
    }



    private CustomerResponseDTO convertToResponseDTO(Customer customer) {
        return new CustomerResponseDTO(
                customer.getId(),
                customer.getName(),
                customer.getEmail()
        );
    }
}
package com.dam.inventory.service;

import com.dam.inventory.dto.ExternalTrackDTO;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import java.util.ArrayList;
import java.util.List;

@Service
public class ExternalApiService {

    private final RestClient restClient;
    private final ObjectMapper objectMapper; // Para procesar el JSON a mano

    public ExternalApiService(RestClient restClient, ObjectMapper objectMapper) {
        this.restClient = restClient;
        this.objectMapper = objectMapper;
    }

    public List<ExternalTrackDTO> searchMusic(String term) {
        try {

            String rawJson = restClient.get()
                    .uri("https://itunes.apple.com/search?term={term}&limit=5", term)
                    .retrieve()
                    .body(String.class);

            JsonNode root = objectMapper.readTree(rawJson);
            JsonNode results = root.path("results");

            List<ExternalTrackDTO> dtoList = new ArrayList<>();


            for (JsonNode node : results) {
                dtoList.add(new ExternalTrackDTO(
                        node.path("artistName").asText(),
                        node.path("trackName").asText(),
                        node.path("previewUrl").asText(),
                        node.path("trackPrice").asDouble(),
                        node.path("currency").asText()
                ));
            }

            return dtoList;

        } catch (Exception e) {

            throw new RuntimeException("Error procesando la API externa: " + e.getMessage());
        }
    }
}
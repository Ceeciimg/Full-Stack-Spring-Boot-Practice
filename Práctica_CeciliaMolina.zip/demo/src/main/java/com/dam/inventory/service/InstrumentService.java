package com.dam.inventory.service;

import com.dam.inventory.dto.InstrumentCreateDTO;
import com.dam.inventory.model.Instrument;
import com.dam.inventory.repository.InstrumentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class InstrumentService {

    @Autowired
    private InstrumentRepository repository;

    public List<Instrument> findAll() {
        return repository.findAll();
    }

    public Optional<Instrument> findById(Long id) {
        return repository.findById(id);
    }

    public List<Instrument> findByBrand(String brand) {
        return repository.findByBrand(brand);
    }

    public Instrument create(InstrumentCreateDTO dto) {

        String cleanName = dto.getName().trim();
        String cleanBrand = dto.getBrand().trim();


        if (repository.existsByNameAndBrand(cleanName, cleanBrand)) {
            throw new IllegalStateException("Ese instrumento ya existe en esta marca");
        }

        Instrument newInstrument = new Instrument(cleanName, cleanBrand);
        return repository.save(newInstrument);
    }
}
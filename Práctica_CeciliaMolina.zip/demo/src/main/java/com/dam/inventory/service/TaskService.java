package com.dam.inventory.service;

import com.dam.inventory.dto.TaskRequestDTO;
import com.dam.inventory.dto.TaskResponseDTO;
import com.dam.inventory.model.Customer;
import com.dam.inventory.model.Task;
import com.dam.inventory.repository.CustomerRepository;
import com.dam.inventory.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TaskService {

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private CustomerRepository customerRepository;

    public List<TaskResponseDTO> findByCustomer(Long customerId) {
        return taskRepository.findByCustomerId(customerId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public TaskResponseDTO createTask(Long customerId, TaskRequestDTO dto) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));

        if (taskRepository.countByCustomerIdAndDoneFalse(customerId) >= 10) {
            throw new IllegalStateException("El cliente ya tiene 10 tareas pendientes");
        }

        Task task = new Task(dto.getTitle().trim(), customer);
        return convertToDTO(taskRepository.save(task));
    }

    public TaskResponseDTO completeTask(Long taskId) {
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Tarea no encontrada"));
        task.setDone(true);
        return convertToDTO(taskRepository.save(task));
    }

    private TaskResponseDTO convertToDTO(Task task) {
        return new TaskResponseDTO(
                task.getId(),
                task.getTitle(),
                task.isDone(),
                task.getCustomer().getId()
        );
    }
}